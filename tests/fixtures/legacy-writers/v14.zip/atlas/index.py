"""Incremental indexer: transcripts -> SQLite. One writer under a file lock."""
from __future__ import annotations

import fcntl
import glob
import os
import re
import sqlite3
import sys
import time
from contextlib import contextmanager
from datetime import datetime, timezone

from . import agents, codex_parse, config, costs, db, paths, search_rows, store

PROJECTS_ROOT = os.environ.get("ATLAS_PROJECTS_ROOT", os.path.join(paths.claude_dir(), "projects"))


def codex_home() -> str:
    """Read on every pass, not at import: tests and the CLI point it at another folder."""
    return os.environ.get("ATLAS_CODEX_HOME") or paths.codex_dir()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


@contextmanager
def writer_lock():
    """Inter-process lock: manual index, CLI refresh and the server timer never write at once."""
    path = os.path.join(db.atlas_home(), "index.lock")
    with open(path, "w") as fh:
        fcntl.flock(fh, fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(fh, fcntl.LOCK_UN)


# Transcripts of our own compressor: indexing them would feed our output back into itself.
RUNNER_SLUG_MARK = "session-atlas-runner"


def discover(root: str = PROJECTS_ROOT) -> list[str]:
    """Sessions live at the second level. Deeper files are subagent transcripts, not sessions."""
    found = glob.glob(os.path.join(root, "*", "*.jsonl"))
    return sorted(p for p in found if RUNNER_SLUG_MARK not in os.path.basename(os.path.dirname(p)))


def discover_codex(home: str | None = None) -> list[str]:
    """Codex rollouts: live ones by date folder, archived ones flat. Other names are not threads."""
    home = home or codex_home()
    found = glob.glob(os.path.join(glob.escape(home), "sessions", "**", "rollout-*.jsonl"), recursive=True)
    found += glob.glob(os.path.join(glob.escape(home), "archived_sessions", "rollout-*.jsonl"))
    return sorted(p for p in found if codex_parse.session_id_of(p))


CODEX_HEAD_BYTES = 8192          # ids and thread source come before the long instructions
_SUBAGENT = re.compile(rb'"thread_source":\s*"subagent"|"source":\s*\{"subagent"')
_PARENT = re.compile(rb'"parent_thread_id":\s*"([0-9a-fA-F-]{36})"')
_codex_heads: dict[str, tuple] = {}   # path → (inode, parent thread id or None): a head never changes


def _codex_parent(path: str) -> str | None:
    """The thread that spawned this one when this is a Codex subagent thread, from the first line."""
    try:
        ino = os.stat(path).st_ino
    except OSError:
        return None
    cached = _codex_heads.get(path)
    if cached and cached[0] == ino:
        return cached[1]
    try:
        with open(path, "rb") as fh:
            head = fh.read(CODEX_HEAD_BYTES)
    except OSError:
        return None
    first = head.split(b"\n", 1)[0]
    found = _PARENT.search(first) if _SUBAGENT.search(first) else None
    parent = found.group(1).decode() if found else None
    _codex_heads[path] = (ino, parent)
    return parent


def codex_subagents(paths: list[str]) -> dict[str, list[str]]:
    """Rollout of a thread → the rollouts of the subagents it spawned, theirs included, as Claude Code
    keeps subagents with their session. A subagent whose root thread is not here stays its own."""
    ids = {p: codex_parse.session_id_of(p) for p in paths}
    present = set(ids.values())
    parent = {ids[p]: _codex_parent(p) for p in paths}
    by_root: dict[str, list[str]] = {}
    for path in paths:
        tid, seen = ids[path], set()
        while parent.get(tid) and tid not in seen:
            seen.add(tid)
            tid = parent[tid]
        if tid != ids[path] and tid in present and not parent.get(tid):
            by_root.setdefault(tid, []).append(path)
    return {p: sorted(by_root[ids[p]]) for p in paths if ids[p] in by_root}


def discover_subagents(session_path: str) -> list[str]:
    """A parked conversation's job links the subagents still running at the hand-over to the
    parent's files: those belong to the parent and are indexed there."""
    session_id = os.path.splitext(os.path.basename(session_path))[0]
    folder = os.path.join(os.path.dirname(session_path), session_id, "subagents")
    return sorted(p for p in glob.glob(os.path.join(glob.escape(folder), "*.jsonl"))
                  if not foreign_link(p, folder))


def foreign_link(path: str, folder: str) -> bool:
    if not os.path.islink(path):
        return False
    real = os.path.dirname(os.path.realpath(path))
    return real != os.path.realpath(folder)


def _signature(session_path: str, subagents: list[str]) -> str:
    """Signature of a session together with its subagents: a change to any file refreshes the parent."""
    parts = []
    for path in [session_path, *subagents]:
        try:
            st = os.stat(path)
        except FileNotFoundError:
            continue
        parts.append(f"{os.path.basename(path)}:{st.st_ino}:{st.st_size}:{st.st_mtime_ns}")
    return "|".join(parts)


def _files_signature(paths: list[str]) -> str:
    parts = []
    for path in paths:
        try:
            st = os.stat(path)
        except FileNotFoundError:
            continue
        parts.append(f"{os.path.basename(path)}:{st.st_ino}:{st.st_size}:{st.st_mtime_ns}")
    return "|".join(parts)


REPRICE_BATCH = 200          # sessions per pass, newest first: about 30 s of parsing, so a long backlog
                             # does not hold the writer lock for minutes (the update button waits on it)


def _reread_newly_priced(conn: sqlite3.Connection) -> None:
    """Replies stored without a price whose model has one now (an update added it, or an older process
    still running stored them) get it by reading their sessions again: the database keeps no 5-minute /
    1-hour split of a cache write. The sources stay, so a vanished file is still purged."""
    models = [m for (m,) in conn.execute("SELECT DISTINCT model FROM activity WHERE cost IS NULL AND model IS NOT NULL")
              if costs.price_for(m) is not None]
    if not models:
        return
    marks = ",".join("?" * len(models))
    stale = (f"SELECT session_id FROM activity WHERE cost IS NULL AND model IN ({marks}) "
             f"GROUP BY session_id ORDER BY MAX(ts) DESC LIMIT {int(REPRICE_BATCH)}")
    with search_rows.writing(conn):      # a write outside the marker would look like an old indexer's
        conn.execute(f"UPDATE sources SET sig = NULL WHERE sig IS NOT NULL AND session_id IN ({stale})", models)
        conn.execute(f"DELETE FROM parse_state WHERE session_id IN ({stale})", models)
    conn.commit()


def _changed(row: sqlite3.Row | None, sig: str) -> bool:
    """The file is reread in full on any mismatch: parsing one file takes milliseconds."""
    return row is None or row["sig"] != sig


def _purge(conn: sqlite3.Connection, session_id: str) -> None:
    store.purge(conn, session_id, gone=True)
    conn.execute("DELETE FROM index_costs WHERE session_id=?", (session_id,))


# A live session with subagents cannot be read on from the last offset when a subagent file
# changed: it is parsed in full. For a large one (644 MB with 260 subagents: ~60 s) that would
# repeat every pass while its agents work, so it waits a multiple of what its last full parse took.
FULL_COST_MIN_S = 5.0        # a cheaper full parse is never put off
FULL_SPACING = 10            # put off for at most this many times its last cost…
FULL_SPACING_MAX_S = 900.0   # …and never longer than this


def _clock() -> float:
    return time.time()       # wall clock: each pass is a new process


def _deferred(conn: sqlite3.Connection, session_id: str) -> bool:
    row = conn.execute("SELECT full_s, at FROM index_costs WHERE session_id=?", (session_id,)).fetchone()
    if row is None or row[0] < FULL_COST_MIN_S:
        return False
    # A clock set back must not stretch the wait: the time since is never negative.
    return 0 <= _clock() - row[1] < min(FULL_SPACING * row[0], FULL_SPACING_MAX_S)


def _note_cost(conn: sqlite3.Connection, session_id: str, seconds: float) -> None:
    conn.execute("INSERT OR REPLACE INTO index_costs VALUES (?,?,?)", (session_id, seconds, _clock()))


def index_one(conn: sqlite3.Connection, path: str, agent: str) -> None:
    """A transcript Atlas has just written ("Resume with…"): in the catalog without waiting for a pass."""
    adapter = agents.adapter(agent, operation="immediate indexing")
    ref = agents.SourceRef(agent, path)
    with writer_lock():
        st = os.stat(path)
        getattr(adapter, "_index_one", _index_one)(conn, ref, st)
        conn.commit()


def _index_one(conn, ref, st):
    store.store_full(conn, ref.locator, st, _signature(ref.locator, []), [], None, agent=ref.agent)


def _index_refs(conn, refs, home, known, present, stats, full, paced, protected):
    """Default file indexing for adapters without native checkpoint or sidecar requirements."""
    for ref in refs:
        path = ref.locator
        present.add(path)
        stats["seen"] += 1
        try:
            st = os.stat(path)
        except FileNotFoundError:
            continue
        sig = _signature(path, [])
        if not full and not _changed(known.get(path), sig):
            stats["skipped"] += 1
            continue
        try:
            sid = store.store_full(conn, path, st, sig, [], None, agent=ref.agent,
                                   protected=protected)
            conn.commit()
            if sid:
                stats["full"] += 1
                stats["indexed"] += 1
        except Exception as exc:
            conn.rollback()
            stats["errors"] += 1
            print(f"atlas index: {path}: {type(exc).__name__}: {exc}", file=sys.stderr)
            _retry_full(conn, path)


def index_all(conn: sqlite3.Connection, root: str = PROJECTS_ROOT,
              full: bool = False, only_if_flagged: bool = False,
              codex_root: str | None = None, paced: bool = False) -> dict:
    """Returns a run summary. Each file is its own transaction: a failure does not break the whole index.
    `paced`: the server's background pass, which may put off an expensive full re-parse. A refresh
    someone asked for (the update button, `atlas search`) is never put off."""
    stats = {"seen": 0, "indexed": 0, "skipped": 0, "removed": 0, "errors": 0,
             "subagent_files": 0, "full": 0, "tail": 0, "codex": 0, "deferred": 0}
    with writer_lock():
        # An old indexer can invalidate the lookup even when every source signature is unchanged.
        with search_rows.writing(conn):
            recovery, generation = conn.execute(
                "SELECT recovery,generation FROM fts_guard WHERE id=1").fetchone()
        conn.commit()
        full = full or bool(recovery)
        # Recheck the flag under the lock: another process may have rebuilt while we waited.
        if only_if_flagged and not recovery and db.get_meta(conn, "needs_reindex") != "1":
            return stats
        home = codex_root or codex_home()
        passes = []
        incomplete = set()
        for kind in agents.all():
            adapter = agents.adapter(kind)
            try:
                status, refs = adapter.discover(root, home)
            except Exception as exc:
                stats["errors"] += 1
                print(f"atlas index: {kind} discovery: {type(exc).__name__}: {exc}", file=sys.stderr)
                incomplete.add(kind)
                continue
            if status != "complete":
                incomplete.add(kind)
                continue
            passes.append((adapter, refs))

        # Repricing works by session_id, which can name sources owned by different agents.
        if not incomplete:
            _reread_newly_priced(conn)
        _reread_copies_once(conn, incomplete)
        known = {r["path"]: r for r in conn.execute("SELECT * FROM sources")}
        protected, owners = _protected_sources(conn, incomplete)
        present = set()
        for adapter, refs in passes:
            getattr(adapter, "_index_refs", _index_refs)(
                conn, refs, home, known, present, stats, full, paced, protected)

        for path, row in known.items():
            if path not in present and row["session_id"] not in protected \
                    and (not incomplete or path in owners):
                # An archived Codex rollout moves to another folder: its session lives on there.
                moved = conn.execute("SELECT 1 FROM sources WHERE session_id=? AND path<>?",
                                     (row["session_id"], path)).fetchone()
                with search_rows.writing(conn):
                    if not moved:
                        _purge(conn, row["session_id"])
                    conn.execute("DELETE FROM sources WHERE path=?", (path,))
                stats["removed"] += 1
        db.set_meta(conn, "indexed_through", _now())
        with search_rows.writing(conn):
            if full and not incomplete:
                conn.execute("UPDATE fts_guard SET recovery=0 WHERE id=1 AND generation=?",
                             (generation,))
            remaining = conn.execute("SELECT recovery FROM fts_guard WHERE id=1").fetchone()[0]
            db.set_meta(conn, "needs_reindex", "1" if remaining or (full and incomplete) else "0")
        conn.commit()
    return stats


def _protected_sources(conn, incomplete):
    if not incomplete:
        return set(), set()
    protected, owners = set(), set()
    for sid, path, kind in conn.execute("SELECT session_id, source_path, agent FROM sessions"):
        if kind in incomplete:
            protected.add(sid)
        else:
            owners.add(path)
    return protected, owners


FORK_MARK = re.compile(rb'"forkedFrom"|"session_id":\s*"([^"]+)"')
FORK_HEAD_BYTES = 512 << 10   # session metadata and attachments come before the first prompt
CODEX_FORK_HEAD_BYTES = 4096  # ids, time and folder come before the long instructions
_TURN = re.compile(rb'"type":\s*"(?:user|assistant)"')


def _foreign(chunk: bytes, own: bytes) -> bool:
    return any(m.group(1) is None or m.group(1) != own for m in FORK_MARK.finditer(chunk))


def is_copy_head(path: str) -> bool:
    """A Claude Code copy (--fork-session, /branch) starts with the source's records: its first
    prompt or reply names another session. Reading stops there, and never goes past the head."""
    own = os.path.splitext(os.path.basename(path))[0].encode()
    seen = 0
    try:
        with open(path, "rb") as fh:
            while seen < FORK_HEAD_BYTES:
                raw = fh.readline(FORK_HEAD_BYTES - seen)
                if not raw:
                    return False
                seen += len(raw)
                turn = _TURN.search(raw)
                if turn or FORK_MARK.search(raw):
                    if _foreign(raw, own):
                        return True
                    if turn and raw.endswith(b"\n"):
                        return False
    except OSError:
        return False
    return False


def is_codex_fork_head(path: str) -> bool:
    """A Codex fork names its source near the start of its first line (session_meta)."""
    try:
        with open(path, "rb") as fh:
            return b'"forked_from_id"' in fh.read(CODEX_FORK_HEAD_BYTES)
    except OSError:
        return False


def _reread_copies_once(conn: sqlite3.Connection, incomplete: set[str]) -> None:
    """Copies indexed before session_forks existed, or before Codex copies were recorded: parse
    them in full once so the table fills."""
    for marker, agent, is_copy in (("copies_scanned", "claude", is_copy_head),
                                   ("codex_copies_scanned", "codex", is_codex_fork_head)):
        if agent in incomplete or db.get_meta(conn, marker) == "1":
            continue
        for row in conn.execute("SELECT source_path FROM sessions WHERE agent = ?", (agent,)).fetchall():
            if is_copy(row["source_path"]):
                _retry_full(conn, row["source_path"])
        db.set_meta(conn, marker, "1")
        conn.commit()


def _retry_full(conn: sqlite3.Connection, path: str) -> None:
    """A broken source must not repeat the whole recovery. Retry just it, even after chmod only.

    Forget the tail checkpoint too: missing turns in an old catalog need a full parse when the
    source becomes readable again. Authoritative and paid data remain untouched.
    """
    with search_rows.writing(conn):
        row = conn.execute("SELECT session_id FROM sources WHERE path=?", (path,)).fetchone()
        if row:
            conn.execute("UPDATE sources SET sig=NULL WHERE path=?", (path,))
            conn.execute("DELETE FROM parse_state WHERE session_id=?", (row["session_id"],))
    conn.commit()


def _relink_continuations(conn: sqlite3.Connection, stats: dict) -> None:
    """A job indexed before its parent's `continued-in` was seen still holds the copied history:
    read it again now that the hand-over time is known."""
    rows = conn.execute(
        """SELECT c.child_id, s.source_path FROM session_continuations c
             JOIN sessions s ON s.session_id = c.child_id
            WHERE s.continued_from IS NOT c.session_id AND s.agent = 'claude'""").fetchall()
    for row in {r["child_id"]: r for r in rows}.values():
        path = row["source_path"]
        try:
            st = os.stat(path)
            subagents = discover_subagents(path)
            store.store_full(conn, path, st, _signature(path, subagents), subagents,
                             _files_signature(subagents))
            conn.commit()
            stats["full"] += 1
        except Exception as exc:  # one unreadable transcript must not stop the pass
            conn.rollback()
            stats["errors"] += 1
            print(f"atlas index: {path}: {type(exc).__name__}: {exc}", file=sys.stderr)
            _retry_full(conn, path)


def reindex_due(conn: sqlite3.Connection) -> bool:
    """A schema change empties the derived tables; a change to settings the index depends on
    (projects, path domains, tickets) makes them stale. Either way a full pass is due."""
    fingerprint = config.index_fingerprint()
    if db.get_meta(conn, "config_fingerprint") != fingerprint:
        db.set_meta(conn, "config_fingerprint", fingerprint)
        db.set_meta(conn, "needs_reindex", "1")
        conn.commit()
    return db.get_meta(conn, "needs_reindex") == "1" or search_rows.pending(conn)


def ensure_indexed(conn: sqlite3.Connection, root: str = PROJECTS_ROOT) -> dict | None:
    """Runs the due full pass in this process; the server leaves it to a background pass instead."""
    if not reindex_due(conn):
        return None
    return index_all(conn, root=root, full=True, only_if_flagged=True)


def index_age_seconds(conn: sqlite3.Connection) -> float | None:
    value = db.get_meta(conn, "indexed_through")
    if not value:
        return None
    return (datetime.now(timezone.utc) - datetime.fromisoformat(value)).total_seconds()
